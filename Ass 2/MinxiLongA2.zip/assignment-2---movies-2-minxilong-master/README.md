# CP1404 Assignment 2 - Movies to Watch 2.0 by YOUR_NAME

A Python project with GUI and Console programs that (re)use classes to manage a list of *Movies to Watch*.


# Project Reflection

## 1. How long did the entire project (assignment 2) take you?
...  
Note: You may like to use the WakaTime plugin, which tracks exactly how long you spend in code. 
See http://wakatime.com (but note that the free version only has a 7-day history)

## 2. What are you most satisfied with?
...

## 3. What are you least satisfied with?
...

## 4. What worked well in your development process?
...

## 5. What about your process could be improved the next time you do a project like this?
...

## 6. Describe what learning resources you used and how you used them.
...

## 7. Describe the main challenges or obstacles you faced and how you overcame them.
... 

## 8. Briefly describe your experience using classes and if/how they improved your code.
...